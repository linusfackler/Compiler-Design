class WhileStatement extends Token {
    
}
