class IfStatement extends Token {
    
}
