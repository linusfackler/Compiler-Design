class Decrement extends Token {
    
}
