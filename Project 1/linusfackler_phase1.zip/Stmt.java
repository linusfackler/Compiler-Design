class Stmt extends Token {
    
}
