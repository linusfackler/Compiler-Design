class Pintlinelist extends Token {
    
}
