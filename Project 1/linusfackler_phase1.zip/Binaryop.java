class Binaryop extends Token {
    
}
