class ConditionalExpression extends Token {
    
}
