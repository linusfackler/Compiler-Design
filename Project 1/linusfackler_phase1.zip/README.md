# CS 4386.001, Compiler Design, Fall 2022
# Project Assignment #1
Linus Fackler - LXF210001

## How to run program
You need to be in an environment, where Java, Jflex, and Cup is installed.
A good option is the UTD cs1 Linux server.
First, cd to the directory with the project files. After that, all you need to do is:
```bash
make
```
