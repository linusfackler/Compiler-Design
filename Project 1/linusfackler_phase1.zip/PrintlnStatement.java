class PrintlnStatement extends Token {
    
}
