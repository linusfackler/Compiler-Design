class Type extends Token {
    
}
