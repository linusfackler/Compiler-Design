class ReturnStatement extends Token {
    
}
