class IDExpression extends Token {
    
}
