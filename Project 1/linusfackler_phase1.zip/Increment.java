class Increment extends Token {
    
}
