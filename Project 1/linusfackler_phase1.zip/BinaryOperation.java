class BinaryOperation extends Token {
    
}
