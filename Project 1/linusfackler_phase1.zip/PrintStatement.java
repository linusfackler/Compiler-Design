class PrintStatement extends Token {
    
}
