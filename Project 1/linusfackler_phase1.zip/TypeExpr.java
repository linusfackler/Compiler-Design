class TypeExpr extends Token {
    
}
