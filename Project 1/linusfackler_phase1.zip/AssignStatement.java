class AssignStatement extends Token {
    
}
