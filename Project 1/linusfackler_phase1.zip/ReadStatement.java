class ReadStatement extends Token {
    
}
