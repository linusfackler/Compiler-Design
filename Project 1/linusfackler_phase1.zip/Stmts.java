class Stmts extends Token {
    
}
