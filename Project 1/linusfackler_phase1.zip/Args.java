class Args extends Token {
    
}
