class IDStatement extends Token {
    
}
