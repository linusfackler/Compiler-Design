class Readlist extends Token {
    
}
