class IfEnd extends Token {
    
}
